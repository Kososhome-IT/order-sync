import prisma from "../../db.server";
import * as NetSuiteClientModule from "./netsuite.client.js";

console.log(
  "NETSUITE MODULE =",
  NetSuiteClientModule
);
export async function processShopifyOrder(orderSyncId) {
  const sync = await prisma.orderSync.findUnique({
    where: {
      id: orderSyncId,
    },
  });

  if (!sync) {
    throw new Error(
      `OrderSync not found: ${orderSyncId}`
    );
  }

  console.log(
    "Processing Shopify Order:",
    sync.shopifyOrderId
  );
  
console.log(
  "TYPEOF createNetSuiteClient =",
  typeof NetSuiteClientModule.createNetSuiteClient
);

console.log(
  "VALUE createNetSuiteClient =",
  NetSuiteClientModule.createNetSuiteClient
);

const client =
  await NetSuiteClientModule.createNetSuiteClient();

  console.log(
    "NetSuite client initialized"
  );

  // Temporary test call
  const result =
    await client.get("/salesOrder");

  console.log(
    "NetSuite Response:",
    result
  );
}